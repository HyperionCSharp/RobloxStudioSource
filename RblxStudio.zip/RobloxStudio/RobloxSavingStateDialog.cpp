/**
 * RobloxSavingStateDialog.cpp
 * Copyright (c) 2013 ROBLOX Corp. All Rights Reserved.
 */

#include "stdafx.h"
#include "RobloxSavingStateDialog.h"

