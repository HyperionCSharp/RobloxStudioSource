/****************************************************************************
** Meta object code from reading C++ file 'RobloxStudioVerbs.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "stdafx.h"
#include "RobloxStudioVerbs.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'RobloxStudioVerbs.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_PasteVerb[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_PasteVerb[] = {
    "PasteVerb\0\0onClipboardModified()\0"
};

void PasteVerb::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        PasteVerb *_t = static_cast<PasteVerb *>(_o);
        switch (_id) {
        case 0: _t->onClipboardModified(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData PasteVerb::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject PasteVerb::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_PasteVerb,
      qt_meta_data_PasteVerb, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &PasteVerb::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *PasteVerb::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *PasteVerb::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_PasteVerb))
        return static_cast<void*>(const_cast< PasteVerb*>(this));
    if (!strcmp(_clname, "RBX::Verb"))
        return static_cast< RBX::Verb*>(const_cast< PasteVerb*>(this));
    return QObject::qt_metacast(_clname);
}

int PasteVerb::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_DuplicateSelectionVerb[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_DuplicateSelectionVerb[] = {
    "DuplicateSelectionVerb\0"
};

void DuplicateSelectionVerb::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData DuplicateSelectionVerb::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject DuplicateSelectionVerb::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_DuplicateSelectionVerb,
      qt_meta_data_DuplicateSelectionVerb, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &DuplicateSelectionVerb::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *DuplicateSelectionVerb::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *DuplicateSelectionVerb::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_DuplicateSelectionVerb))
        return static_cast<void*>(const_cast< DuplicateSelectionVerb*>(this));
    if (!strcmp(_clname, "RBX::EditSelectionVerb"))
        return static_cast< RBX::EditSelectionVerb*>(const_cast< DuplicateSelectionVerb*>(this));
    return QObject::qt_metacast(_clname);
}

int DuplicateSelectionVerb::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_CreateNewLinkedSourceVerb[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_CreateNewLinkedSourceVerb[] = {
    "CreateNewLinkedSourceVerb\0"
};

void CreateNewLinkedSourceVerb::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData CreateNewLinkedSourceVerb::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CreateNewLinkedSourceVerb::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_CreateNewLinkedSourceVerb,
      qt_meta_data_CreateNewLinkedSourceVerb, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CreateNewLinkedSourceVerb::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CreateNewLinkedSourceVerb::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CreateNewLinkedSourceVerb::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CreateNewLinkedSourceVerb))
        return static_cast<void*>(const_cast< CreateNewLinkedSourceVerb*>(this));
    if (!strcmp(_clname, "RBX::Verb"))
        return static_cast< RBX::Verb*>(const_cast< CreateNewLinkedSourceVerb*>(this));
    return QObject::qt_metacast(_clname);
}

int CreateNewLinkedSourceVerb::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_ScreenshotVerb[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      16,   15,   15,   15, 0x08,
      41,   15,   15,   15, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_ScreenshotVerb[] = {
    "ScreenshotVerb\0\0showPostImageWebDialog()\0"
    "copyImageToClipboard()\0"
};

void ScreenshotVerb::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ScreenshotVerb *_t = static_cast<ScreenshotVerb *>(_o);
        switch (_id) {
        case 0: _t->showPostImageWebDialog(); break;
        case 1: _t->copyImageToClipboard(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData ScreenshotVerb::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ScreenshotVerb::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_ScreenshotVerb,
      qt_meta_data_ScreenshotVerb, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ScreenshotVerb::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ScreenshotVerb::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ScreenshotVerb::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ScreenshotVerb))
        return static_cast<void*>(const_cast< ScreenshotVerb*>(this));
    if (!strcmp(_clname, "RBX::Verb"))
        return static_cast< RBX::Verb*>(const_cast< ScreenshotVerb*>(this));
    return QObject::qt_metacast(_clname);
}

int ScreenshotVerb::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
static const uint qt_meta_data_OpenToolBoxWithOptionsVerb[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      38,   28,   27,   27, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_OpenToolBoxWithOptionsVerb[] = {
    "OpenToolBoxWithOptionsVerb\0\0isVisible\0"
    "handleDockVisibilityChanged(bool)\0"
};

void OpenToolBoxWithOptionsVerb::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        OpenToolBoxWithOptionsVerb *_t = static_cast<OpenToolBoxWithOptionsVerb *>(_o);
        switch (_id) {
        case 0: _t->handleDockVisibilityChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData OpenToolBoxWithOptionsVerb::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject OpenToolBoxWithOptionsVerb::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_OpenToolBoxWithOptionsVerb,
      qt_meta_data_OpenToolBoxWithOptionsVerb, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &OpenToolBoxWithOptionsVerb::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *OpenToolBoxWithOptionsVerb::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *OpenToolBoxWithOptionsVerb::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_OpenToolBoxWithOptionsVerb))
        return static_cast<void*>(const_cast< OpenToolBoxWithOptionsVerb*>(this));
    if (!strcmp(_clname, "RBX::Verb"))
        return static_cast< RBX::Verb*>(const_cast< OpenToolBoxWithOptionsVerb*>(this));
    return QObject::qt_metacast(_clname);
}

int OpenToolBoxWithOptionsVerb::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_RecordToggleVerb[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      18,   17,   17,   17, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_RecordToggleVerb[] = {
    "RecordToggleVerb\0\0uploadVideo()\0"
};

void RecordToggleVerb::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        RecordToggleVerb *_t = static_cast<RecordToggleVerb *>(_o);
        switch (_id) {
        case 0: _t->uploadVideo(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData RecordToggleVerb::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject RecordToggleVerb::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_RecordToggleVerb,
      qt_meta_data_RecordToggleVerb, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &RecordToggleVerb::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *RecordToggleVerb::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *RecordToggleVerb::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_RecordToggleVerb))
        return static_cast<void*>(const_cast< RecordToggleVerb*>(this));
    if (!strcmp(_clname, "RBX::Verb"))
        return static_cast< RBX::Verb*>(const_cast< RecordToggleVerb*>(this));
    return QObject::qt_metacast(_clname);
}

int RecordToggleVerb::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_ExportSelectionVerb[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_ExportSelectionVerb[] = {
    "ExportSelectionVerb\0"
};

void ExportSelectionVerb::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData ExportSelectionVerb::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ExportSelectionVerb::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_ExportSelectionVerb,
      qt_meta_data_ExportSelectionVerb, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ExportSelectionVerb::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ExportSelectionVerb::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ExportSelectionVerb::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ExportSelectionVerb))
        return static_cast<void*>(const_cast< ExportSelectionVerb*>(this));
    if (!strcmp(_clname, "RBX::Verb"))
        return static_cast< RBX::Verb*>(const_cast< ExportSelectionVerb*>(this));
    return QObject::qt_metacast(_clname);
}

int ExportSelectionVerb::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_ExportPlaceVerb[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_ExportPlaceVerb[] = {
    "ExportPlaceVerb\0"
};

void ExportPlaceVerb::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData ExportPlaceVerb::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ExportPlaceVerb::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_ExportPlaceVerb,
      qt_meta_data_ExportPlaceVerb, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ExportPlaceVerb::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ExportPlaceVerb::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ExportPlaceVerb::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ExportPlaceVerb))
        return static_cast<void*>(const_cast< ExportPlaceVerb*>(this));
    if (!strcmp(_clname, "RBX::Verb"))
        return static_cast< RBX::Verb*>(const_cast< ExportPlaceVerb*>(this));
    return QObject::qt_metacast(_clname);
}

int ExportPlaceVerb::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE
