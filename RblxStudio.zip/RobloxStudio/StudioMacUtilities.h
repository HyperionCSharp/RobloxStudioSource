#pragma once

namespace StudioMacUtilities
{
    void disableAppNap(const char* reason);
    void enableAppNap();
}

