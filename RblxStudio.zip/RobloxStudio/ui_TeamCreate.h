/********************************************************************************
** Form generated from reading UI file 'TeamCreate.ui'
**
** Created by: Qt User Interface Compiler version 4.8.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TEAMCREATE_H
#define UI_TEAMCREATE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QStackedWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TeamCreate
{
public:
    QGridLayout *gridLayout_6;
    QStackedWidget *mainStackedWidget;
    QWidget *mainEmptyPage;
    QGridLayout *gridLayout_15;
    QFrame *frame_2;
    QWidget *publishPage;
    QGridLayout *gridLayout_16;
    QFrame *frame_3;
    QGridLayout *gridLayout_2;
    QVBoxLayout *verticalLayout_3;
    QSpacerItem *verticalSpacer_4;
    QLabel *publishMessageLabel;
    QSpacerItem *verticalSpacer_5;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *publishButton;
    QSpacerItem *horizontalSpacer_5;
    QSpacerItem *verticalSpacer_6;
    QWidget *publishingMessagePage;
    QGridLayout *gridLayout_19;
    QFrame *frame_5;
    QGridLayout *gridLayout_18;
    QVBoxLayout *verticalLayout_11;
    QSpacerItem *verticalSpacer_22;
    QLabel *publishingMessageLabel;
    QSpacerItem *verticalSpacer_23;
    QWidget *optionsPage;
    QGridLayout *gridLayout_3;
    QVBoxLayout *verticalLayout;
    QStackedWidget *optionsStackedWidget;
    QWidget *loginPage;
    QGridLayout *gridLayout_14;
    QFrame *frame;
    QGridLayout *gridLayout_4;
    QVBoxLayout *verticalLayout_2;
    QSpacerItem *verticalSpacer;
    QLabel *loginMessageLabel;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *loginButton;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer_2;
    QWidget *userPlaceOptionsPage;
    QGridLayout *gridLayout_8;
    QVBoxLayout *verticalLayout_6;
    QLineEdit *friendsInviteEdit;
    QStackedWidget *userPlaceStackedWidget;
    QWidget *userPlaceTurnOnPage;
    QGridLayout *gridLayout_7;
    QVBoxLayout *verticalLayout_5;
    QSpacerItem *verticalSpacer_11;
    QLabel *userPlaceTurnOnLabel;
    QSpacerItem *verticalSpacer_10;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *userPlaceTurnOnButton;
    QSpacerItem *horizontalSpacer_10;
    QSpacerItem *verticalSpacer_12;
    QWidget *userPlaceSaveMessagePage;
    QGridLayout *gridLayout_9;
    QVBoxLayout *verticalLayout_7;
    QSpacerItem *verticalSpacer_13;
    QLabel *userPlaceSaveMessageLabel;
    QSpacerItem *verticalSpacer_14;
    QWidget *userPlaceCreatorsListPage;
    QWidget *groupPlaceOptionsPage;
    QGridLayout *gridLayout_11;
    QStackedWidget *groupPlaceStackedWidget;
    QWidget *groupPlaceTurnOnPage;
    QGridLayout *gridLayout_10;
    QVBoxLayout *verticalLayout_8;
    QSpacerItem *verticalSpacer_16;
    QLabel *groupPlaceTurnOnMessageLabel;
    QSpacerItem *verticalSpacer_15;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_11;
    QPushButton *groupPlaceTurnOnButton;
    QSpacerItem *horizontalSpacer_12;
    QSpacerItem *verticalSpacer_17;
    QWidget *groupPlaceNonAdminPage;
    QGridLayout *gridLayout_12;
    QVBoxLayout *verticalLayout_9;
    QSpacerItem *verticalSpacer_18;
    QLabel *groupPlaceNonAdminMessage;
    QSpacerItem *verticalSpacer_19;
    QWidget *groupPlaceSaveMessagePage;
    QGridLayout *gridLayout_13;
    QVBoxLayout *verticalLayout_10;
    QSpacerItem *verticalSpacer_20;
    QLabel *groupPlaceSaveMessageLabel;
    QSpacerItem *verticalSpacer_21;
    QWidget *groupPlaceCreatorsListPage;
    QFrame *bottomBarFrame;
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *bottomMoreButton;
    QWidget *userRemoveConfirmPage;
    QGridLayout *gridLayout_17;
    QFrame *frame_4;
    QGridLayout *gridLayout_5;
    QVBoxLayout *verticalLayout_4;
    QSpacerItem *verticalSpacer_7;
    QLabel *userRemoveLabel;
    QSpacerItem *verticalSpacer_9;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *userRemoveButton;
    QSpacerItem *horizontalSpacer_8;
    QPushButton *userRemoveCancelButton;
    QSpacerItem *horizontalSpacer_7;
    QSpacerItem *verticalSpacer_8;

    void setupUi(QWidget *TeamCreate)
    {
        if (TeamCreate->objectName().isEmpty())
            TeamCreate->setObjectName(QString::fromUtf8("TeamCreate"));
        TeamCreate->resize(354, 425);
        gridLayout_6 = new QGridLayout(TeamCreate);
        gridLayout_6->setSpacing(0);
        gridLayout_6->setContentsMargins(0, 0, 0, 0);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        mainStackedWidget = new QStackedWidget(TeamCreate);
        mainStackedWidget->setObjectName(QString::fromUtf8("mainStackedWidget"));
        mainStackedWidget->setFrameShadow(QFrame::Raised);
        mainEmptyPage = new QWidget();
        mainEmptyPage->setObjectName(QString::fromUtf8("mainEmptyPage"));
        gridLayout_15 = new QGridLayout(mainEmptyPage);
        gridLayout_15->setContentsMargins(0, 0, 0, 0);
        gridLayout_15->setObjectName(QString::fromUtf8("gridLayout_15"));
        frame_2 = new QFrame(mainEmptyPage);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setFrameShape(QFrame::Box);
        frame_2->setFrameShadow(QFrame::Raised);

        gridLayout_15->addWidget(frame_2, 0, 0, 1, 1);

        mainStackedWidget->addWidget(mainEmptyPage);
        publishPage = new QWidget();
        publishPage->setObjectName(QString::fromUtf8("publishPage"));
        gridLayout_16 = new QGridLayout(publishPage);
        gridLayout_16->setSpacing(4);
        gridLayout_16->setContentsMargins(0, 0, 0, 0);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        frame_3 = new QFrame(publishPage);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setFrameShape(QFrame::Box);
        frame_3->setFrameShadow(QFrame::Raised);
        gridLayout_2 = new QGridLayout(frame_3);
        gridLayout_2->setSpacing(4);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(6, 4, 6, 4);
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_4);

        publishMessageLabel = new QLabel(frame_3);
        publishMessageLabel->setObjectName(QString::fromUtf8("publishMessageLabel"));
        publishMessageLabel->setAlignment(Qt::AlignCenter);
        publishMessageLabel->setWordWrap(true);

        verticalLayout_3->addWidget(publishMessageLabel);

        verticalSpacer_5 = new QSpacerItem(20, 13, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_3->addItem(verticalSpacer_5);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);

        publishButton = new QPushButton(frame_3);
        publishButton->setObjectName(QString::fromUtf8("publishButton"));
        publishButton->setStyleSheet(QString::fromUtf8("background-color: #02b757;\n"
"                    color: rgb(255, 255, 255);\n"
"                  "));

        horizontalLayout_2->addWidget(publishButton);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_5);


        verticalLayout_3->addLayout(horizontalLayout_2);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_6);


        gridLayout_2->addLayout(verticalLayout_3, 0, 0, 1, 1);


        gridLayout_16->addWidget(frame_3, 0, 0, 1, 1);

        mainStackedWidget->addWidget(publishPage);
        publishingMessagePage = new QWidget();
        publishingMessagePage->setObjectName(QString::fromUtf8("publishingMessagePage"));
        gridLayout_19 = new QGridLayout(publishingMessagePage);
        gridLayout_19->setSpacing(4);
        gridLayout_19->setContentsMargins(0, 0, 0, 0);
        gridLayout_19->setObjectName(QString::fromUtf8("gridLayout_19"));
        frame_5 = new QFrame(publishingMessagePage);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setFrameShape(QFrame::Box);
        frame_5->setFrameShadow(QFrame::Raised);
        gridLayout_18 = new QGridLayout(frame_5);
        gridLayout_18->setSpacing(4);
        gridLayout_18->setContentsMargins(4, 4, 4, 4);
        gridLayout_18->setObjectName(QString::fromUtf8("gridLayout_18"));
        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        verticalLayout_11->setContentsMargins(4, -1, 4, -1);
        verticalSpacer_22 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_11->addItem(verticalSpacer_22);

        publishingMessageLabel = new QLabel(frame_5);
        publishingMessageLabel->setObjectName(QString::fromUtf8("publishingMessageLabel"));
        publishingMessageLabel->setAlignment(Qt::AlignCenter);
        publishingMessageLabel->setWordWrap(true);

        verticalLayout_11->addWidget(publishingMessageLabel);

        verticalSpacer_23 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_11->addItem(verticalSpacer_23);


        gridLayout_18->addLayout(verticalLayout_11, 0, 0, 1, 1);


        gridLayout_19->addWidget(frame_5, 0, 0, 1, 1);

        mainStackedWidget->addWidget(publishingMessagePage);
        optionsPage = new QWidget();
        optionsPage->setObjectName(QString::fromUtf8("optionsPage"));
        gridLayout_3 = new QGridLayout(optionsPage);
        gridLayout_3->setSpacing(4);
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        optionsStackedWidget = new QStackedWidget(optionsPage);
        optionsStackedWidget->setObjectName(QString::fromUtf8("optionsStackedWidget"));
        optionsStackedWidget->setFrameShape(QFrame::NoFrame);
        optionsStackedWidget->setFrameShadow(QFrame::Plain);
        loginPage = new QWidget();
        loginPage->setObjectName(QString::fromUtf8("loginPage"));
        gridLayout_14 = new QGridLayout(loginPage);
        gridLayout_14->setSpacing(4);
        gridLayout_14->setContentsMargins(0, 0, 0, 0);
        gridLayout_14->setObjectName(QString::fromUtf8("gridLayout_14"));
        frame = new QFrame(loginPage);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setFrameShape(QFrame::Box);
        frame->setFrameShadow(QFrame::Raised);
        gridLayout_4 = new QGridLayout(frame);
        gridLayout_4->setSpacing(0);
        gridLayout_4->setContentsMargins(4, 4, 4, 4);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(4);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        loginMessageLabel = new QLabel(frame);
        loginMessageLabel->setObjectName(QString::fromUtf8("loginMessageLabel"));
        loginMessageLabel->setAlignment(Qt::AlignCenter);
        loginMessageLabel->setWordWrap(true);

        verticalLayout_2->addWidget(loginMessageLabel);

        verticalSpacer_3 = new QSpacerItem(20, 13, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        loginButton = new QPushButton(frame);
        loginButton->setObjectName(QString::fromUtf8("loginButton"));
        loginButton->setStyleSheet(QString::fromUtf8(" background-color: #02b757;\n"
"                          color: rgb(255, 255, 255);\n"
"                        "));

        horizontalLayout->addWidget(loginButton);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        verticalLayout_2->addLayout(horizontalLayout);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);


        gridLayout_4->addLayout(verticalLayout_2, 0, 0, 1, 1);


        gridLayout_14->addWidget(frame, 0, 0, 1, 1);

        optionsStackedWidget->addWidget(loginPage);
        userPlaceOptionsPage = new QWidget();
        userPlaceOptionsPage->setObjectName(QString::fromUtf8("userPlaceOptionsPage"));
        gridLayout_8 = new QGridLayout(userPlaceOptionsPage);
        gridLayout_8->setSpacing(4);
        gridLayout_8->setContentsMargins(0, 0, 0, 0);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(4);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        friendsInviteEdit = new QLineEdit(userPlaceOptionsPage);
        friendsInviteEdit->setObjectName(QString::fromUtf8("friendsInviteEdit"));

        verticalLayout_6->addWidget(friendsInviteEdit);

        userPlaceStackedWidget = new QStackedWidget(userPlaceOptionsPage);
        userPlaceStackedWidget->setObjectName(QString::fromUtf8("userPlaceStackedWidget"));
        userPlaceStackedWidget->setFrameShape(QFrame::Box);
        userPlaceStackedWidget->setFrameShadow(QFrame::Raised);
        userPlaceTurnOnPage = new QWidget();
        userPlaceTurnOnPage->setObjectName(QString::fromUtf8("userPlaceTurnOnPage"));
        gridLayout_7 = new QGridLayout(userPlaceTurnOnPage);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalSpacer_11 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_11);

        userPlaceTurnOnLabel = new QLabel(userPlaceTurnOnPage);
        userPlaceTurnOnLabel->setObjectName(QString::fromUtf8("userPlaceTurnOnLabel"));
        userPlaceTurnOnLabel->setAlignment(Qt::AlignCenter);
        userPlaceTurnOnLabel->setWordWrap(true);

        verticalLayout_5->addWidget(userPlaceTurnOnLabel);

        verticalSpacer_10 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_5->addItem(verticalSpacer_10);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_9);

        userPlaceTurnOnButton = new QPushButton(userPlaceTurnOnPage);
        userPlaceTurnOnButton->setObjectName(QString::fromUtf8("userPlaceTurnOnButton"));
        userPlaceTurnOnButton->setStyleSheet(QString::fromUtf8("background-color: #02b757;\n"
"                            color: rgb(255, 255, 255);\n"
"                          "));

        horizontalLayout_4->addWidget(userPlaceTurnOnButton);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_10);


        verticalLayout_5->addLayout(horizontalLayout_4);

        verticalSpacer_12 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_12);


        gridLayout_7->addLayout(verticalLayout_5, 0, 0, 1, 1);

        userPlaceStackedWidget->addWidget(userPlaceTurnOnPage);
        userPlaceSaveMessagePage = new QWidget();
        userPlaceSaveMessagePage->setObjectName(QString::fromUtf8("userPlaceSaveMessagePage"));
        gridLayout_9 = new QGridLayout(userPlaceSaveMessagePage);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalSpacer_13 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer_13);

        userPlaceSaveMessageLabel = new QLabel(userPlaceSaveMessagePage);
        userPlaceSaveMessageLabel->setObjectName(QString::fromUtf8("userPlaceSaveMessageLabel"));
        userPlaceSaveMessageLabel->setAlignment(Qt::AlignCenter);
        userPlaceSaveMessageLabel->setWordWrap(true);

        verticalLayout_7->addWidget(userPlaceSaveMessageLabel);

        verticalSpacer_14 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer_14);


        gridLayout_9->addLayout(verticalLayout_7, 0, 0, 1, 1);

        userPlaceStackedWidget->addWidget(userPlaceSaveMessagePage);
        userPlaceCreatorsListPage = new QWidget();
        userPlaceCreatorsListPage->setObjectName(QString::fromUtf8("userPlaceCreatorsListPage"));
        userPlaceStackedWidget->addWidget(userPlaceCreatorsListPage);

        verticalLayout_6->addWidget(userPlaceStackedWidget);


        gridLayout_8->addLayout(verticalLayout_6, 0, 0, 1, 1);

        optionsStackedWidget->addWidget(userPlaceOptionsPage);
        groupPlaceOptionsPage = new QWidget();
        groupPlaceOptionsPage->setObjectName(QString::fromUtf8("groupPlaceOptionsPage"));
        gridLayout_11 = new QGridLayout(groupPlaceOptionsPage);
        gridLayout_11->setContentsMargins(0, 0, 0, 0);
        gridLayout_11->setObjectName(QString::fromUtf8("gridLayout_11"));
        groupPlaceStackedWidget = new QStackedWidget(groupPlaceOptionsPage);
        groupPlaceStackedWidget->setObjectName(QString::fromUtf8("groupPlaceStackedWidget"));
        groupPlaceStackedWidget->setFrameShape(QFrame::Box);
        groupPlaceStackedWidget->setFrameShadow(QFrame::Raised);
        groupPlaceTurnOnPage = new QWidget();
        groupPlaceTurnOnPage->setObjectName(QString::fromUtf8("groupPlaceTurnOnPage"));
        gridLayout_10 = new QGridLayout(groupPlaceTurnOnPage);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalSpacer_16 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_8->addItem(verticalSpacer_16);

        groupPlaceTurnOnMessageLabel = new QLabel(groupPlaceTurnOnPage);
        groupPlaceTurnOnMessageLabel->setObjectName(QString::fromUtf8("groupPlaceTurnOnMessageLabel"));
        groupPlaceTurnOnMessageLabel->setAlignment(Qt::AlignCenter);
        groupPlaceTurnOnMessageLabel->setWordWrap(true);

        verticalLayout_8->addWidget(groupPlaceTurnOnMessageLabel);

        verticalSpacer_15 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_8->addItem(verticalSpacer_15);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_11);

        groupPlaceTurnOnButton = new QPushButton(groupPlaceTurnOnPage);
        groupPlaceTurnOnButton->setObjectName(QString::fromUtf8("groupPlaceTurnOnButton"));

        horizontalLayout_5->addWidget(groupPlaceTurnOnButton);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_12);


        verticalLayout_8->addLayout(horizontalLayout_5);

        verticalSpacer_17 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_8->addItem(verticalSpacer_17);


        gridLayout_10->addLayout(verticalLayout_8, 0, 0, 1, 1);

        groupPlaceStackedWidget->addWidget(groupPlaceTurnOnPage);
        groupPlaceNonAdminPage = new QWidget();
        groupPlaceNonAdminPage->setObjectName(QString::fromUtf8("groupPlaceNonAdminPage"));
        gridLayout_12 = new QGridLayout(groupPlaceNonAdminPage);
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalSpacer_18 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_9->addItem(verticalSpacer_18);

        groupPlaceNonAdminMessage = new QLabel(groupPlaceNonAdminPage);
        groupPlaceNonAdminMessage->setObjectName(QString::fromUtf8("groupPlaceNonAdminMessage"));
        groupPlaceNonAdminMessage->setAlignment(Qt::AlignCenter);
        groupPlaceNonAdminMessage->setWordWrap(true);

        verticalLayout_9->addWidget(groupPlaceNonAdminMessage);

        verticalSpacer_19 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_9->addItem(verticalSpacer_19);


        gridLayout_12->addLayout(verticalLayout_9, 0, 0, 1, 1);

        groupPlaceStackedWidget->addWidget(groupPlaceNonAdminPage);
        groupPlaceSaveMessagePage = new QWidget();
        groupPlaceSaveMessagePage->setObjectName(QString::fromUtf8("groupPlaceSaveMessagePage"));
        gridLayout_13 = new QGridLayout(groupPlaceSaveMessagePage);
        gridLayout_13->setObjectName(QString::fromUtf8("gridLayout_13"));
        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalSpacer_20 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_20);

        groupPlaceSaveMessageLabel = new QLabel(groupPlaceSaveMessagePage);
        groupPlaceSaveMessageLabel->setObjectName(QString::fromUtf8("groupPlaceSaveMessageLabel"));
        groupPlaceSaveMessageLabel->setAlignment(Qt::AlignCenter);
        groupPlaceSaveMessageLabel->setWordWrap(true);

        verticalLayout_10->addWidget(groupPlaceSaveMessageLabel);

        verticalSpacer_21 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_21);


        gridLayout_13->addLayout(verticalLayout_10, 0, 0, 1, 1);

        groupPlaceStackedWidget->addWidget(groupPlaceSaveMessagePage);
        groupPlaceCreatorsListPage = new QWidget();
        groupPlaceCreatorsListPage->setObjectName(QString::fromUtf8("groupPlaceCreatorsListPage"));
        groupPlaceStackedWidget->addWidget(groupPlaceCreatorsListPage);

        gridLayout_11->addWidget(groupPlaceStackedWidget, 0, 0, 1, 1);

        optionsStackedWidget->addWidget(groupPlaceOptionsPage);

        verticalLayout->addWidget(optionsStackedWidget);

        bottomBarFrame = new QFrame(optionsPage);
        bottomBarFrame->setObjectName(QString::fromUtf8("bottomBarFrame"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(bottomBarFrame->sizePolicy().hasHeightForWidth());
        bottomBarFrame->setSizePolicy(sizePolicy);
        bottomBarFrame->setMinimumSize(QSize(0, 20));
        bottomBarFrame->setMaximumSize(QSize(16777215, 20));
        bottomBarFrame->setStyleSheet(QString::fromUtf8("background-color: #e6e6e6;"));
        bottomBarFrame->setFrameShape(QFrame::Box);
        bottomBarFrame->setFrameShadow(QFrame::Raised);
        gridLayout = new QGridLayout(bottomBarFrame);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(4, 0, 4, 0);
        horizontalSpacer = new QSpacerItem(275, 15, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 0, 1, 1);

        bottomMoreButton = new QPushButton(bottomBarFrame);
        bottomMoreButton->setObjectName(QString::fromUtf8("bottomMoreButton"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(bottomMoreButton->sizePolicy().hasHeightForWidth());
        bottomMoreButton->setSizePolicy(sizePolicy1);
        bottomMoreButton->setMinimumSize(QSize(18, 18));
        bottomMoreButton->setMaximumSize(QSize(18, 18));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/16x16/images/Studio 2.0 icons/16x16/team_create_more.png"), QSize(), QIcon::Normal, QIcon::Off);
        bottomMoreButton->setIcon(icon);
        bottomMoreButton->setIconSize(QSize(16, 16));
        bottomMoreButton->setFlat(true);

        gridLayout->addWidget(bottomMoreButton, 0, 1, 1, 1);


        verticalLayout->addWidget(bottomBarFrame);


        gridLayout_3->addLayout(verticalLayout, 0, 0, 1, 1);

        mainStackedWidget->addWidget(optionsPage);
        userRemoveConfirmPage = new QWidget();
        userRemoveConfirmPage->setObjectName(QString::fromUtf8("userRemoveConfirmPage"));
        gridLayout_17 = new QGridLayout(userRemoveConfirmPage);
        gridLayout_17->setSpacing(4);
        gridLayout_17->setContentsMargins(0, 0, 0, 0);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        frame_4 = new QFrame(userRemoveConfirmPage);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setFrameShape(QFrame::Box);
        frame_4->setFrameShadow(QFrame::Raised);
        gridLayout_5 = new QGridLayout(frame_4);
        gridLayout_5->setSpacing(4);
        gridLayout_5->setContentsMargins(4, 4, 4, 4);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_7);

        userRemoveLabel = new QLabel(frame_4);
        userRemoveLabel->setObjectName(QString::fromUtf8("userRemoveLabel"));
        userRemoveLabel->setAlignment(Qt::AlignCenter);
        userRemoveLabel->setWordWrap(true);

        verticalLayout_4->addWidget(userRemoveLabel);

        verticalSpacer_9 = new QSpacerItem(20, 13, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_4->addItem(verticalSpacer_9);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_6);

        userRemoveButton = new QPushButton(frame_4);
        userRemoveButton->setObjectName(QString::fromUtf8("userRemoveButton"));
        userRemoveButton->setStyleSheet(QString::fromUtf8("background-color: #e2231a;\n"
"                    color: rgb(255, 255, 255);\n"
"                  "));

        horizontalLayout_3->addWidget(userRemoveButton);

        horizontalSpacer_8 = new QSpacerItem(10, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_8);

        userRemoveCancelButton = new QPushButton(frame_4);
        userRemoveCancelButton->setObjectName(QString::fromUtf8("userRemoveCancelButton"));

        horizontalLayout_3->addWidget(userRemoveCancelButton);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_7);


        verticalLayout_4->addLayout(horizontalLayout_3);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_8);


        gridLayout_5->addLayout(verticalLayout_4, 0, 0, 1, 1);


        gridLayout_17->addWidget(frame_4, 0, 0, 1, 1);

        mainStackedWidget->addWidget(userRemoveConfirmPage);

        gridLayout_6->addWidget(mainStackedWidget, 0, 0, 1, 1);


        retranslateUi(TeamCreate);

        mainStackedWidget->setCurrentIndex(0);
        optionsStackedWidget->setCurrentIndex(1);
        userPlaceStackedWidget->setCurrentIndex(0);
        groupPlaceStackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(TeamCreate);
    } // setupUi

    void retranslateUi(QWidget *TeamCreate)
    {
        TeamCreate->setWindowTitle(QApplication::translate("TeamCreate", "Form", 0, QApplication::UnicodeUTF8));
        publishMessageLabel->setText(QApplication::translate("TeamCreate", "Publish and enable Team Create to build this place together with your friends.", 0, QApplication::UnicodeUTF8));
        publishButton->setText(QApplication::translate("TeamCreate", "Publish", 0, QApplication::UnicodeUTF8));
        publishingMessageLabel->setText(QApplication::translate("TeamCreate", "Publishing current place...", 0, QApplication::UnicodeUTF8));
        loginMessageLabel->setText(QApplication::translate("TeamCreate", "Log in to enable Team Create options for your place.", 0, QApplication::UnicodeUTF8));
        loginButton->setText(QApplication::translate("TeamCreate", "Log In", 0, QApplication::UnicodeUTF8));
        friendsInviteEdit->setPlaceholderText(QApplication::translate("TeamCreate", "Invite a friend", 0, QApplication::UnicodeUTF8));
        userPlaceTurnOnLabel->setText(QApplication::translate("TeamCreate", "Edit your place with friends, see the updates instantly.", 0, QApplication::UnicodeUTF8));
        userPlaceTurnOnButton->setText(QApplication::translate("TeamCreate", "Turn ON", 0, QApplication::UnicodeUTF8));
        userPlaceSaveMessageLabel->setText(QApplication::translate("TeamCreate", "Saving latest updates and enabling Team Create...", 0, QApplication::UnicodeUTF8));
        groupPlaceTurnOnMessageLabel->setText(QApplication::translate("TeamCreate", "Enable Team Create: edit your place together, see updates instantly.", 0, QApplication::UnicodeUTF8));
        groupPlaceTurnOnButton->setText(QApplication::translate("TeamCreate", "Turn ON", 0, QApplication::UnicodeUTF8));
        groupPlaceNonAdminMessage->setText(QApplication::translate("TeamCreate", "Members of your group can work together, see updates instantly. Contact your admin to enable Team Create.", 0, QApplication::UnicodeUTF8));
        groupPlaceSaveMessageLabel->setText(QApplication::translate("TeamCreate", "Saving latest updates and enabling Team Create...", 0, QApplication::UnicodeUTF8));
        bottomMoreButton->setText(QString());
        userRemoveLabel->setText(QApplication::translate("TeamCreate", "Are you sure to remove?", 0, QApplication::UnicodeUTF8));
        userRemoveButton->setText(QApplication::translate("TeamCreate", "Remove", 0, QApplication::UnicodeUTF8));
        userRemoveCancelButton->setText(QApplication::translate("TeamCreate", "Cancel", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class TeamCreate: public Ui_TeamCreate {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TEAMCREATE_H
