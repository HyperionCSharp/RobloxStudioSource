/****************************************************************************
** Meta object code from reading C++ file 'ScriptComboBox.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "stdafx.h"
#include "ScriptComboBox.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ScriptComboBox.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ScriptComboBox[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      25,   16,   15,   15, 0x0a,
      67,   15,   15,   15, 0x08,
     101,   96,   15,   15, 0x08,
     127,   15,   15,   15, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_ScriptComboBox[] = {
    "ScriptComboBox\0\0listItem\0"
    "intellesenseDoubleClick(QListWidgetItem*)\0"
    "onScriptInputReturnPressed()\0text\0"
    "onEditorTextEdit(QString)\0"
    "onItemSelectionFromView()\0"
};

void ScriptComboBox::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ScriptComboBox *_t = static_cast<ScriptComboBox *>(_o);
        switch (_id) {
        case 0: _t->intellesenseDoubleClick((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 1: _t->onScriptInputReturnPressed(); break;
        case 2: _t->onEditorTextEdit((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->onItemSelectionFromView(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData ScriptComboBox::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ScriptComboBox::staticMetaObject = {
    { &QComboBox::staticMetaObject, qt_meta_stringdata_ScriptComboBox,
      qt_meta_data_ScriptComboBox, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ScriptComboBox::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ScriptComboBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ScriptComboBox::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ScriptComboBox))
        return static_cast<void*>(const_cast< ScriptComboBox*>(this));
    return QComboBox::qt_metacast(_clname);
}

int ScriptComboBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QComboBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
