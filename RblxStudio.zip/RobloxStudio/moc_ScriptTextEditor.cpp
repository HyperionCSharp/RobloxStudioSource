/****************************************************************************
** Meta object code from reading C++ file 'ScriptTextEditor.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "stdafx.h"
#include "ScriptTextEditor.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ScriptTextEditor.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ScriptTraversalThread[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_ScriptTraversalThread[] = {
    "ScriptTraversalThread\0"
};

void ScriptTraversalThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData ScriptTraversalThread::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ScriptTraversalThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_ScriptTraversalThread,
      qt_meta_data_ScriptTraversalThread, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ScriptTraversalThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ScriptTraversalThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ScriptTraversalThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ScriptTraversalThread))
        return static_cast<void*>(const_cast< ScriptTraversalThread*>(this));
    return QThread::qt_metacast(_clname);
}

int ScriptTraversalThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_CheckSyntaxThread[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_CheckSyntaxThread[] = {
    "CheckSyntaxThread\0"
};

void CheckSyntaxThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData CheckSyntaxThread::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CheckSyntaxThread::staticMetaObject = {
    { &ScriptTraversalThread::staticMetaObject, qt_meta_stringdata_CheckSyntaxThread,
      qt_meta_data_CheckSyntaxThread, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CheckSyntaxThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CheckSyntaxThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CheckSyntaxThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CheckSyntaxThread))
        return static_cast<void*>(const_cast< CheckSyntaxThread*>(this));
    return ScriptTraversalThread::qt_metacast(_clname);
}

int CheckSyntaxThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ScriptTraversalThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_FindThread[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_FindThread[] = {
    "FindThread\0"
};

void FindThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData FindThread::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject FindThread::staticMetaObject = {
    { &ScriptTraversalThread::staticMetaObject, qt_meta_stringdata_FindThread,
      qt_meta_data_FindThread, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &FindThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *FindThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *FindThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FindThread))
        return static_cast<void*>(const_cast< FindThread*>(this));
    return ScriptTraversalThread::qt_metacast(_clname);
}

int FindThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ScriptTraversalThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_ScriptTextEditor[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
      29,   18,   17,   17, 0x05,
      76,   56,   51,   17, 0x05,
     114,  104,   17,   17, 0x05,
     156,  150,   17,   17, 0x05,

 // slots: signature, parameters, type, tag, flags
     182,   17,   17,   17, 0x0a,
     198,   17,   17,   17, 0x08,
     221,  212,   17,   17, 0x08,
     263,   17,   17,   17, 0x08,
     288,   17,   17,   17, 0x08,
     313,   17,   17,   17, 0x08,
     331,   17,   17,   17, 0x08,
     359,   17,   17,   17, 0x08,
     366,   17,   17,   17, 0x08,
     408,  375,   17,   17, 0x08,
     423,   17,   17,   17, 0x28,

 // methods: signature, parameters, type, tag, flags
     457,  434,   17,   17, 0x02,
     499,  483,   17,   17, 0x02,
     546,   17,   17,   17, 0x02,

       0        // eod
};

static const char qt_meta_stringdata_ScriptTextEditor[] = {
    "ScriptTextEditor\0\0lineNumber\0"
    "toggleBreakpoint(int)\0bool\0"
    "pos,wordUnderCursor\0showToolTip(QPoint,QString)\0"
    "pMenu,pos\0updateContextualMenu(QMenu*,QPoint)\0"
    "topic\0helpTopicChanged(QString)\0"
    "onCheckSyntax()\0checkSyntax()\0listItem\0"
    "intellesenseDoubleClick(QListWidgetItem*)\0"
    "updateCursorVisibility()\0"
    "selectionChangedSearch()\0onSearchTimeout()\0"
    "onCheckSyntaxTimerTimeOut()\0find()\0"
    "onFind()\0moveCursorToBeginningOfSelection\0"
    "findNext(bool)\0findNext()\0"
    "errorLine,errorMessage\0setErrorLine(int,QString)\0"
    "analysisResults\0"
    "setAnalysisResult(RBX::ScriptAnalyzer::Result)\0"
    "startFind()\0"
};

void ScriptTextEditor::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ScriptTextEditor *_t = static_cast<ScriptTextEditor *>(_o);
        switch (_id) {
        case 0: _t->toggleBreakpoint((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: { bool _r = _t->showToolTip((*reinterpret_cast< const QPoint(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 2: _t->updateContextualMenu((*reinterpret_cast< QMenu*(*)>(_a[1])),(*reinterpret_cast< QPoint(*)>(_a[2]))); break;
        case 3: _t->helpTopicChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->onCheckSyntax(); break;
        case 5: _t->checkSyntax(); break;
        case 6: _t->intellesenseDoubleClick((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 7: _t->updateCursorVisibility(); break;
        case 8: _t->selectionChangedSearch(); break;
        case 9: _t->onSearchTimeout(); break;
        case 10: _t->onCheckSyntaxTimerTimeOut(); break;
        case 11: _t->find(); break;
        case 12: _t->onFind(); break;
        case 13: _t->findNext((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->findNext(); break;
        case 15: _t->setErrorLine((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 16: _t->setAnalysisResult((*reinterpret_cast< const RBX::ScriptAnalyzer::Result(*)>(_a[1]))); break;
        case 17: _t->startFind(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData ScriptTextEditor::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ScriptTextEditor::staticMetaObject = {
    { &QPlainTextEdit::staticMetaObject, qt_meta_stringdata_ScriptTextEditor,
      qt_meta_data_ScriptTextEditor, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ScriptTextEditor::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ScriptTextEditor::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ScriptTextEditor::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ScriptTextEditor))
        return static_cast<void*>(const_cast< ScriptTextEditor*>(this));
    if (!strcmp(_clname, "IFindListener"))
        return static_cast< IFindListener*>(const_cast< ScriptTextEditor*>(this));
    return QPlainTextEdit::qt_metacast(_clname);
}

int ScriptTextEditor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QPlainTextEdit::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void ScriptTextEditor::toggleBreakpoint(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
bool ScriptTextEditor::showToolTip(const QPoint & _t1, const QString & _t2)
{
    bool _t0;
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(&_t0)), const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
    return _t0;
}

// SIGNAL 2
void ScriptTextEditor::updateContextualMenu(QMenu * _t1, QPoint _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void ScriptTextEditor::helpTopicChanged(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_END_MOC_NAMESPACE
